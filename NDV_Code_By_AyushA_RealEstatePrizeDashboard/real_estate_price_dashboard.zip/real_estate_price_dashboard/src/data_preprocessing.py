import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler

def load_data(path):
    """Load CSV data from the specified path."""
    return pd.read_csv(path)

def preprocess_data(df):
    """Clean, encode, and scale the data."""
    df = df.dropna()

    # Encode categoricals
    label_encoders = {}
    categorical_cols = df.select_dtypes(include='object').columns
    for col in categorical_cols:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col])
        label_encoders[col] = le

    # Scale numerics
    scaler = StandardScaler()
    numeric_cols = df.select_dtypes(include='number').columns
    df[numeric_cols] = scaler.fit_transform(df[numeric_cols])

    return df, label_encoders, scaler