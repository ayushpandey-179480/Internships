import streamlit as st
import pandas as pd
import joblib

# Load trained model
model = joblib.load('models/best_model.pkl')

# UI
st.title("🏠 Real Estate Price Prediction Dashboard")
st.markdown("Enter property details to predict its price.")

location = st.number_input("Location (encoded number)", min_value=0)
sqft = st.number_input("Square Footage", min_value=100)
bhk = st.number_input("Number of BHK", min_value=1)
amenities = st.number_input("Amenities Score (0-10)", min_value=0.0, max_value=10.0)

if st.button("Predict Price"):
    input_data = pd.DataFrame([[location, sqft, bhk, amenities]],
                              columns=['Location', 'Sqft', 'BHK', 'Amenities'])
    prediction = model.predict(input_data)[0]
    st.success(f"🏷 Estimated Price: ₹ {prediction:,.2f}")