# 🏠 Real Estate Price Prediction Dashboard

## 📌 About
A complete ML project to predict property prices based on features like location, sqft, BHK, and amenities, deployed via Streamlit.

## 🚀 How to Run

1. *Install dependencies*
```bash
pip install -r requirements.txt