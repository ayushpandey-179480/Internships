import pandas as pd
import numpy as np
import os
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from data_preprocessing import preprocess_data

# 1. Load data
df = pd.read_csv('data/processed/cleaned_data.csv')

# 2. Preprocess (encode, scale, etc.)
df, encoders, scaler = preprocess_data(df)

# 3. Split into X and y
X = df.drop('Price', axis=1)
y = df['Price']

# 4. Train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# 5. Build and train model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# 6. Predictions and evaluation
preds = model.predict(X_test)

rmse = np.sqrt(mean_squared_error(y_test, preds))
mae = mean_absolute_error(y_test, preds)
r2 = r2_score(y_test, preds)

print("✅ Model Evaluation Metrics:")
print(f"RMSE: {rmse:.2f}")
print(f"MAE: {mae:.2f}")
print(f"R2 Score: {r2:.2f}")

# 7. Save the model
os.makedirs('models', exist_ok=True)  # ensure folder exists
joblib.dump(model, 'models/best_model.pkl')
print("✅ Model saved to models/best_model.pkl")